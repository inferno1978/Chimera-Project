#!/usr/bin/env python3
"""Small, root-only OpenFlux exit-node controller used by WPP."""

import json
import os
import pwd
import re
import secrets
import shutil
import subprocess
import tempfile
import time
import base64
import zlib
from pathlib import Path
from urllib.parse import urlsplit

CONFIG_DIR = Path("/etc/web-proxy-panel/openflux")
STATE_FILE = CONFIG_DIR / "config.json"
URL_FILE = CONFIG_DIR / "document-url"
KEY_FILE = CONFIG_DIR / "encryption-key"
ENABLED_FILE = CONFIG_DIR / "enabled"
BIN = Path("/opt/web-panel-proxy/openflux/openflux")
UNIT = Path("/etc/systemd/system/web-panel-proxy-openflux.service")
SERVICE = "web-panel-proxy-openflux.service"
SERVICE_USER = "wpp-openflux"
LEGACY_IOS_DROPIN = Path("/etc/systemd/system/web-panel-proxy-openflux.service.d/ios.conf")
PROFILES_DIR = CONFIG_DIR / "profiles"
VERSION = "1.0.0"
MAX_OPENFLUX_PROFILES = 32
TRANSPORT = "yandex"
TRANSPORTS = {"yandex", "mailru", "telemost", "oneme"}
CODEC = "batched"
MODE = "l4"
_LINK_CACHE = {}


class OpenFluxError(RuntimeError):
    pass


def _codec_for(config):
    """Use the codec built into the current iOS and Android clients."""
    return CODEC


def _clean_transport(value):
    value = str(value or TRANSPORT).strip().lower()
    if value not in TRANSPORTS:
        raise OpenFluxError("Выберите Яндекс Документы, Яндекс Телемост, Mail.ru Документы или MAX.")
    return value


def _transport_for(config):
    value = str((config or {}).get("transport", TRANSPORT)).lower()
    return value if value in TRANSPORTS else TRANSPORT


def _run(args, *, check=True, timeout=20):
    try:
        return subprocess.run(args, text=True, capture_output=True, timeout=timeout, check=check)
    except (OSError, subprocess.SubprocessError) as exc:
        detail = getattr(exc, "stderr", "") or getattr(exc, "stdout", "") or str(exc)
        raise OpenFluxError(detail.strip()[-1200:] or "OpenFlux command failed") from exc


def _share_payload(config):
    """Return the official OpenFlux share.Config for document transports."""
    transport = _transport_for(config)
    if transport not in {"yandex", "mailru", "telemost"}:
        return None
    url = str(config.get("url") or "").strip()
    if not url:
        return None
    payload = {
        "name": str(config.get("name") or "OpenFlux"),
        "transports": [{"type": transport, "url": url}],
    }
    ios = config.get("platform") == "ios" or bool(config.get("ios_compatible", False))
    if not ios:
        secret = str(config.get("key") or "")
        if secret:
            payload.update({"secret": secret, "context": url})
    return payload


def _python_share_link(payload):
    """Compatibility fallback for an installed core predating --make-link."""
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    # share.Encode/Decode in OpenFlux use raw DEFLATE, not a zlib envelope.
    # A wrapped stream produces code=damaged in the official clients.
    compressor = zlib.compressobj(level=9, wbits=-zlib.MAX_WBITS)
    packed = compressor.compress(raw) + compressor.flush()
    return "openflux://v1/" + base64.urlsafe_b64encode(packed).decode("ascii").rstrip("=")


def make_import_uri(config):
    """Build the same openflux://v1 link consumed by the current iOS core."""
    payload = _share_payload(config)
    if payload is None:
        return ""
    cache_key = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    cached = _LINK_CACHE.get(cache_key)
    if cached:
        return cached
    link = ""
    try:
        result = _run([str(BIN), "--make-link", json.dumps(payload, ensure_ascii=False)], timeout=12)
        answer = json.loads(result.stdout)
        candidate = str(answer.get("link") or "") if isinstance(answer, dict) else ""
        if candidate.startswith("openflux://v1/"):
            link = candidate
    except (OpenFluxError, ValueError, TypeError):
        pass
    if not link:
        link = _python_share_link(payload)
    if len(_LINK_CACHE) >= 128:
        _LINK_CACHE.clear()
    _LINK_CACHE[cache_key] = link
    return link


def _atomic(path, value, mode, uid=0, gid=0):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        os.chown(temporary, uid, gid)
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def validate_document_url(value, transport=TRANSPORT):
    transport = _clean_transport(transport)
    value = str(value or "").strip()
    if not value or len(value) > 2048 or any(ord(char) < 32 for char in value):
        label = "конференцию Телемоста" if transport == "telemost" else "публичный документ"
        raise OpenFluxError(f"Укажите корректную ссылку на {label}.")
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as exc:
        raise OpenFluxError("Ссылка на документ имеет неверный формат.") from exc
    host = (parsed.hostname or "").lower().rstrip(".")
    if transport == "mailru":
        allowed = host == "cloud.mail.ru" and bool(re.fullmatch(r"/public/[^/]+/[^/]+/?", parsed.path))
        provider = "Mail.ru"
    elif transport == "telemost":
        allowed = host == "telemost.yandex.ru" and parsed.path not in ("", "/")
        provider = "Яндекс Телемоста"
    else:
        allowed = host in {"yandex.ru", "yandex.com"} or host.endswith(".yandex.ru") or host.endswith(".yandex.com")
        provider = "Яндекса"
    if parsed.scheme != "https" or not allowed or port not in (None, 443):
        raise OpenFluxError(f"Укажите публичную HTTPS-ссылку на документ {provider}.")
    if parsed.username or parsed.password or parsed.fragment or not parsed.path or parsed.path == "/":
        raise OpenFluxError("Используйте публичную ссылку на конкретный документ без логина и фрагмента.")
    return value


def _clean_max_token(value, label):
    value = str(value or "").strip()
    if not value or len(value) > 4096 or any(ord(char) < 33 or ord(char) == 127 for char in value):
        raise OpenFluxError(f"Укажите корректный {label} MAX.")
    return value


def _clean_max_uid(value):
    value = str(value or "").strip()
    if not re.fullmatch(r"[1-9][0-9]{0,18}", value) or int(value) > 9223372036854775807:
        raise OpenFluxError("Укажите числовой UID серверного аккаунта MAX.")
    return int(value)


def _load():
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        raise OpenFluxError("Конфигурация OpenFlux повреждена.") from exc
    return data if isinstance(data, dict) else {}


def _service_active():
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "--quiet", SERVICE],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
            check=False,
        )
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _identity():
    try:
        account = pwd.getpwnam(SERVICE_USER)
    except KeyError as exc:
        raise OpenFluxError("Системный пользователь OpenFlux не создан. Повторите обновление WPP.") from exc
    return account.pw_uid, account.pw_gid


def _write_private_files(config):
    uid, gid = _identity()
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    os.chown(CONFIG_DIR, 0, gid)
    os.chmod(CONFIG_DIR, 0o750)
    _atomic(URL_FILE, config["url"] + "\n", 0o640, 0, gid)
    _atomic(KEY_FILE, config["key"] + "\n", 0o640, 0, gid)
    _atomic(STATE_FILE, json.dumps(config, ensure_ascii=True, indent=2) + "\n", 0o600)
    if config.get("enabled", True):
        _atomic(ENABLED_FILE, "enabled\n", 0o600)
    else:
        try:
            ENABLED_FILE.unlink()
        except FileNotFoundError:
            pass


def _unit_text(config=None):
    config = config if isinstance(config, dict) else _load()
    encryption_argument = "" if config.get("ios_compatible", False) else f" --encryption-key-file={KEY_FILE}"
    codec = _codec_for(config)
    transport = _transport_for(config)
    return f"""[Unit]
Description=WEB PANEL PROXY OpenFlux exit node
After=network-online.target
Wants=network-online.target
ConditionPathExists={ENABLED_FILE}

[Service]
Type=simple
User={SERVICE_USER}
Group={SERVICE_USER}
UMask=0077
ExecStart=/bin/sh -c 'exec {BIN} --role=exit --mode={MODE} --codec={codec} --transport={transport} --url "$$(cat {URL_FILE})"{encryption_argument}'
Restart=on-failure
RestartSec=4
TimeoutStopSec=15
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6
RestrictNamespaces=true
LockPersonality=true
CapabilityBoundingSet=
AmbientCapabilities=

[Install]
WantedBy=multi-user.target
"""


def install_service():
    if not BIN.is_file() or not os.access(BIN, os.X_OK):
        raise OpenFluxError("Бинарник OpenFlux не установлен. Повторите обновление WPP.")
    config = _load()
    try:
        legacy_dropin_text = LEGACY_IOS_DROPIN.read_text(encoding="utf-8")
    except FileNotFoundError:
        legacy_dropin_text = ""
    if legacy_dropin_text and "--encryption-key-file" not in legacy_dropin_text:
        config["ios_compatible"] = True
        if config.get("url") and config.get("key"):
            _write_private_files(config)
    expected = _unit_text(config)
    try:
        current = UNIT.read_text(encoding="utf-8")
    except FileNotFoundError:
        current = ""
    legacy_dropin_removed = False
    try:
        LEGACY_IOS_DROPIN.unlink()
        legacy_dropin_removed = True
    except FileNotFoundError:
        pass
    if current != expected:
        _atomic(UNIT, expected, 0o644)
        legacy_dropin_removed = True
    if legacy_dropin_removed:
        _run(["systemctl", "daemon-reload"])


def _start():
    install_service()
    _run(["systemctl", "restart", SERVICE])
    stable = 0
    for _ in range(40):
        if _service_active():
            stable += 1
            if stable >= 12:
                return
        else:
            stable = 0
        time.sleep(0.25)
    journal = _run(["journalctl", "-u", SERVICE, "-n", "30", "--no-pager"], check=False).stdout
    raise OpenFluxError("OpenFlux не запустился. " + journal.strip()[-900:])


def configure(document_url, ios_compatible=False, transport=TRANSPORT):
    transport = _clean_transport(transport)
    url = validate_document_url(document_url, transport)
    previous = _load()
    config = {
        "enabled": True,
        "url": url,
        "key": previous.get("key") if isinstance(previous.get("key"), str) and len(previous["key"]) >= 24 else secrets.token_urlsafe(32),
        "transport": transport,
        "codec": CODEC,
        "mode": MODE,
        "ios_compatible": bool(ios_compatible),
        "version": VERSION,
        "updated_at": int(time.time()),
    }
    _write_private_files(config)
    try:
        _start()
    except Exception:
        if previous.get("url") and previous.get("key"):
            _write_private_files(previous)
            try:
                _start()
            except Exception:
                pass
        else:
            subprocess.run(["systemctl", "stop", SERVICE], check=False, timeout=15)
        raise
    return state()


def set_enabled(enabled):
    config = _load()
    if not config.get("url") or not config.get("key"):
        raise OpenFluxError("Сначала сохраните ссылку на документ.")
    config["enabled"] = bool(enabled)
    config["updated_at"] = int(time.time())
    _write_private_files(config)
    if enabled:
        try:
            _start()
        except Exception:
            config["enabled"] = False
            _write_private_files(config)
            subprocess.run(["systemctl", "stop", SERVICE], check=False, timeout=15)
            raise
    else:
        _run(["systemctl", "stop", SERVICE], check=False)
    return state()


def rotate_key():
    config = _load()
    if not config.get("url"):
        raise OpenFluxError("Сначала сохраните ссылку на документ.")
    previous = dict(config)
    config["key"] = secrets.token_urlsafe(32)
    config["enabled"] = True
    config["updated_at"] = int(time.time())
    _write_private_files(config)
    try:
        _start()
    except Exception:
        _write_private_files(previous)
        if previous.get("enabled", True):
            try:
                _start()
            except Exception:
                pass
        raise
    return state()


def restore_if_configured():
    config = _load()
    if not config.get("url") or not config.get("key"):
        restored = False
    else:
        _write_private_files(config)
        install_service()
        if config.get("enabled", True):
            _start()
        else:
            _run(["systemctl", "stop", SERVICE], check=False)
        restored = True
    for profile in _extra_configs():
        _write_extra_files(profile)
        _install_extra_service(profile)
        if profile.get("enabled", True):
            _start_extra(profile)
        else:
            _run(["systemctl", "stop", _extra_service(profile["id"])], check=False)
    return restored or bool(_extra_configs())


def state():
    config = _load()
    configured = bool(config.get("url") and config.get("key"))
    return {
        "configured": configured,
        "enabled": bool(config.get("enabled", True)) if configured else False,
        "active": _service_active() if configured else False,
        "url": config.get("url", "") if configured else "",
        "key": config.get("key", "") if configured else "",
        "transport": _transport_for(config),
        "codec": _codec_for(config),
        "mode": MODE,
        "ios_compatible": bool(config.get("ios_compatible", False)),
        "encrypted": not bool(config.get("ios_compatible", False)),
        "version": VERSION,
    }


def _clean_profile_name(value):
    value = str(value or "").strip()
    if not value or len(value) > 80 or any(ord(char) < 32 for char in value):
        raise OpenFluxError("Укажите имя профиля длиной от 1 до 80 символов.")
    return value


def _clean_platform(value):
    value = str(value or "").lower()
    if value not in ("ios", "android"):
        raise OpenFluxError("Выберите iOS или Android.")
    return value


def _extra_id(value):
    value = str(value or "")
    if not re.fullmatch(r"[a-f0-9]{16}", value):
        raise OpenFluxError("Профиль OpenFlux не найден.")
    return value


def _extra_paths(profile_id):
    directory = PROFILES_DIR / _extra_id(profile_id)
    return {
        "dir": directory,
        "state": directory / "config.json",
        "url": directory / "document-url",
        "key": directory / "encryption-key",
        "max_token": directory / "max-server-token",
        "enabled": directory / "enabled",
        "unit": Path("/etc/systemd/system") / ("web-panel-proxy-openflux-" + profile_id + ".service"),
    }


def _extra_service(profile_id):
    return "web-panel-proxy-openflux-" + _extra_id(profile_id) + ".service"


def _extra_configs():
    result = []
    try:
        entries = list(PROFILES_DIR.iterdir())
    except FileNotFoundError:
        return result
    for entry in entries:
        if not entry.is_dir() or not re.fullmatch(r"[a-f0-9]{16}", entry.name):
            continue
        try:
            value = json.loads((entry / "config.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(value, dict) and value.get("id") == entry.name:
            result.append(value)
    def created(item):
        try:
            return int(item.get("created_at", 0))
        except (TypeError, ValueError):
            return 0
    return sorted(result, key=lambda item: (created(item), item["id"]))


def _write_extra_files(config):
    paths = _extra_paths(config["id"])
    _, gid = _identity()
    paths["dir"].mkdir(parents=True, exist_ok=True)
    os.chown(paths["dir"], 0, gid)
    os.chmod(paths["dir"], 0o750)
    transport = _transport_for(config)
    _atomic(paths["url"], str(config.get("url", "")) + "\n", 0o640, 0, gid)
    _atomic(paths["key"], config["key"] + "\n", 0o640, 0, gid)
    if transport == "oneme":
        _atomic(paths["max_token"], config["max_server_token"] + "\n", 0o640, 0, gid)
    else:
        try:
            paths["max_token"].unlink()
        except FileNotFoundError:
            pass
    _atomic(paths["state"], json.dumps(config, ensure_ascii=True, indent=2) + "\n", 0o600)
    if config.get("enabled", True):
        _atomic(paths["enabled"], "enabled\n", 0o600)
    else:
        try:
            paths["enabled"].unlink()
        except FileNotFoundError:
            pass


def _extra_unit_text(config):
    paths = _extra_paths(config["id"])
    encryption = "" if config.get("platform") == "ios" else " --encryption-key-file=" + str(paths["key"])
    codec = _codec_for(config)
    transport = _transport_for(config)
    if transport == "oneme":
        max_uid = _clean_max_uid(config.get("max_uid", ""))
        transport_arguments = (
            f'--transport=oneme --maxToken "$$(cat {paths["max_token"]})" '
            f'--maxUid={max_uid}'
        )
    else:
        transport_arguments = f'--transport={transport} --url "$$(cat {paths["url"]})"'
    return f"""[Unit]
Description=WEB PANEL PROXY OpenFlux profile {config['id']}
After=network-online.target
Wants=network-online.target
ConditionPathExists={paths['enabled']}

[Service]
Type=simple
User={SERVICE_USER}
Group={SERVICE_USER}
UMask=0077
ExecStart=/bin/sh -c 'exec {BIN} --role=exit --mode={MODE} --codec={codec} {transport_arguments}{encryption}'
Restart=on-failure
RestartSec=4
TimeoutStopSec=15
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6
RestrictNamespaces=true
LockPersonality=true
CapabilityBoundingSet=
AmbientCapabilities=

[Install]
WantedBy=multi-user.target
"""


def _install_extra_service(config):
    if not BIN.is_file() or not os.access(BIN, os.X_OK):
        raise OpenFluxError("Бинарник OpenFlux не установлен. Повторите обновление WPP.")
    paths = _extra_paths(config["id"])
    expected = _extra_unit_text(config)
    try:
        current = paths["unit"].read_text(encoding="utf-8")
    except FileNotFoundError:
        current = ""
    if current != expected:
        try:
            _atomic(paths["unit"], expected, 0o644)
        except OSError as exc:
            raise OpenFluxError(
                "Панель не может записать службу OpenFlux в /etc/systemd/system. "
                "Повторите обновление WPP, чтобы применить разрешение systemd."
            ) from exc
        _run(["systemctl", "daemon-reload"])


def _extra_active(profile_id):
    try:
        return subprocess.run(["systemctl", "is-active", "--quiet", _extra_service(profile_id)],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                              timeout=5, check=False).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _extra_activity(configs):
    """Read all profile service states with one systemd process."""
    services = [_extra_service(config["id"]) for config in configs]
    if not services:
        return {}
    try:
        completed = subprocess.run(
            ["systemctl", "is-active", *services],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=7,
            check=False,
        )
        states = completed.stdout.splitlines()
        return {config["id"]: index < len(states) and states[index].strip() == "active"
                for index, config in enumerate(configs)}
    except (OSError, subprocess.SubprocessError):
        return {config["id"]: False for config in configs}


def _start_extra(config):
    _install_extra_service(config)
    service = _extra_service(config["id"])
    _run(["systemctl", "enable", service])
    _run(["systemctl", "restart", service])
    stable = 0
    for _ in range(40):
        if _extra_active(config["id"]):
            stable += 1
            if stable >= 12:
                return
        else:
            stable = 0
        time.sleep(0.25)
    journal = _run(["journalctl", "-u", service, "-n", "30", "--no-pager"], check=False).stdout
    raise OpenFluxError("Профиль OpenFlux не запустился. " + journal.strip()[-900:])


def profile_states():
    result = []
    main = state()
    if main["configured"]:
        main.update({"id": "main", "name": _load().get("name", "OpenFlux"),
                     "platform": "ios" if main["ios_compatible"] else "android"})
        main["import_uri"] = make_import_uri({**_load(), **main})
        result.append(main)
    configs = _extra_configs()
    activity = _extra_activity(configs)
    for config in configs:
        try:
            max_uid = int(config.get("max_uid", 0) or 0)
        except (TypeError, ValueError):
            max_uid = 0
        try:
            created_at = int(config.get("created_at", 0) or 0)
        except (TypeError, ValueError):
            created_at = 0
        item = {
            "id": config["id"], "name": config.get("name", "OpenFlux"),
            "platform": config.get("platform", "android"), "url": config.get("url", ""),
            "key": config.get("key", ""), "configured": True,
            "enabled": bool(config.get("enabled", True)), "active": activity.get(config["id"], False),
            "encrypted": config.get("platform") != "ios", "transport": _transport_for(config),
            "codec": _codec_for(config), "version": VERSION,
            "max_client_token": config.get("max_client_token", ""),
            "has_max_server_token": bool(config.get("max_server_token")),
            "max_uid": max_uid,
            "created_at": created_at,
        }
        item["import_uri"] = make_import_uri(config)
        result.append(item)
    return result


def create_profile(name, document_url, platform, transport=TRANSPORT,
                   max_server_token="", max_client_token="", max_uid=""):
    if len(_extra_configs()) >= MAX_OPENFLUX_PROFILES:
        raise OpenFluxError("Достигнут лимит профилей OpenFlux.")
    profile_id = secrets.token_hex(8)
    transport = _clean_transport(transport)
    platform = _clean_platform(platform)
    if transport == "oneme":
        document_url = ""
        max_server_token = _clean_max_token(max_server_token, "токен серверного аккаунта")
        max_client_token = _clean_max_token(max_client_token, "токен клиентского аккаунта")
        max_uid = _clean_max_uid(max_uid)
        if max_server_token == max_client_token:
            raise OpenFluxError("Для сервера и клиента нужны разные аккаунты MAX.")
        for item in _extra_configs():
            try:
                item_max_uid = int(item.get("max_uid", 0) or 0)
            except (TypeError, ValueError):
                item_max_uid = 0
            if item.get("transport") == "oneme" and (
                    item.get("max_server_token") == max_server_token or
                    item_max_uid == max_uid):
                raise OpenFluxError("Этот серверный аккаунт MAX уже используется другим профилем.")
    else:
        document_url = validate_document_url(document_url, transport)
        existing_urls = {item.get("url") for item in _extra_configs()}
        existing_urls.add(_load().get("url"))
        if document_url in existing_urls:
            item_name = "Эта конференция" if transport == "telemost" else "Этот документ"
            raise OpenFluxError(f"{item_name} уже используется другим профилем OpenFlux.")
    config = {"id": profile_id, "name": _clean_profile_name(name),
              "url": document_url, "platform": platform,
              "key": secrets.token_urlsafe(32), "enabled": True, "transport": transport,
              "codec": CODEC, "mode": MODE, "version": VERSION,
              "created_at": int(time.time()), "updated_at": int(time.time())}
    if transport == "oneme":
        config.update({"max_server_token": max_server_token,
                       "max_client_token": max_client_token, "max_uid": max_uid})
    _write_extra_files(config)
    try:
        _start_extra(config)
    except OpenFluxError as exc:
        # Creation and service startup are separate outcomes.  Keep a valid
        # profile when the binary or its remote transport cannot start yet;
        # otherwise the UI appears to ignore the Create button and the user
        # loses every entered value.  A later Enable action retries startup.
        _run(["systemctl", "disable", "--now", _extra_service(profile_id)], check=False)
        config["enabled"] = False
        config["startup_warning"] = str(exc).strip()[-900:]
        config["updated_at"] = int(time.time())
        _write_extra_files(config)
        return config
    config.pop("startup_warning", None)
    _write_extra_files(config)
    return config


def profile_set_enabled(profile_id, enabled):
    if profile_id == "main":
        return set_enabled(enabled)
    config = next((item for item in _extra_configs() if item["id"] == _extra_id(profile_id)), None)
    if config is None:
        raise OpenFluxError("Профиль OpenFlux не найден.")
    config["enabled"] = bool(enabled)
    config["updated_at"] = int(time.time())
    _write_extra_files(config)
    if enabled:
        try:
            _start_extra(config)
        except Exception:
            config["enabled"] = False
            _write_extra_files(config)
            _run(["systemctl", "stop", _extra_service(config["id"])], check=False)
            raise
    else:
        _run(["systemctl", "stop", _extra_service(config["id"])], check=False)


def profile_update(profile_id, name, document_url, platform, transport=TRANSPORT,
                   max_server_token="", max_client_token="", max_uid=""):
    """Update an existing profile in place and restore it on startup failure."""
    name = _clean_profile_name(name)
    platform = _clean_platform(platform)
    transport = _clean_transport(transport)
    if profile_id == "main":
        if transport == "oneme":
            raise OpenFluxError("Для основного профиля MAX недоступен. Создайте отдельный профиль OpenFlux.")
        document_url = validate_document_url(document_url, transport)
        previous = _load()
        if not previous.get("url") or not previous.get("key"):
            raise OpenFluxError("Профиль OpenFlux не найден.")
        config = dict(previous)
        config.update({"name": name, "url": document_url, "transport": transport,
                       "ios_compatible": platform == "ios", "enabled": bool(previous.get("enabled", True)),
                       "codec": CODEC, "mode": MODE, "version": VERSION,
                       "updated_at": int(time.time())})
        _write_private_files(config)
        try:
            install_service()
            if config["enabled"]:
                _start()
            else:
                _run(["systemctl", "stop", SERVICE], check=False)
        except Exception:
            _write_private_files(previous)
            try:
                install_service()
                if previous.get("enabled", True):
                    _start()
            except Exception:
                pass
            raise
        return config

    profile_id = _extra_id(profile_id)
    current = next((item for item in _extra_configs() if item["id"] == profile_id), None)
    if current is None:
        raise OpenFluxError("Профиль OpenFlux не найден.")
    previous = dict(current)
    config = dict(current)
    config.update({"name": name, "platform": platform, "transport": transport,
                   "codec": CODEC, "mode": MODE, "version": VERSION,
                   "updated_at": int(time.time())})
    if transport == "oneme":
        server_token = str(max_server_token or current.get("max_server_token", ""))
        client_token = str(max_client_token or current.get("max_client_token", ""))
        server_token = _clean_max_token(server_token, "токен серверного аккаунта")
        client_token = _clean_max_token(client_token, "токен клиентского аккаунта")
        max_uid = _clean_max_uid(max_uid or current.get("max_uid", ""))
        if server_token == client_token:
            raise OpenFluxError("Для сервера и клиента нужны разные аккаунты MAX.")
        for item in _extra_configs():
            if item.get("id") == profile_id:
                continue
            try:
                item_uid = int(item.get("max_uid", 0) or 0)
            except (TypeError, ValueError):
                item_uid = 0
            if item.get("transport") == "oneme" and (
                    item.get("max_server_token") == server_token or item_uid == max_uid):
                raise OpenFluxError("Этот серверный аккаунт MAX уже используется другим профилем.")
        config.update({"url": "", "max_server_token": server_token,
                       "max_client_token": client_token, "max_uid": max_uid})
    else:
        document_url = validate_document_url(document_url, transport)
        for item in _extra_configs():
            if item.get("id") != profile_id and item.get("url") == document_url:
                label = "Эта конференция" if transport == "telemost" else "Этот документ"
                raise OpenFluxError(f"{label} уже используется другим профилем OpenFlux.")
        if _load().get("url") == document_url:
            raise OpenFluxError("Этот документ уже используется основным профилем OpenFlux.")
        config["url"] = document_url
        config.pop("max_server_token", None)
        config.pop("max_client_token", None)
        config.pop("max_uid", None)
    _run(["systemctl", "stop", _extra_service(profile_id)], check=False)
    _write_extra_files(config)
    try:
        if config.get("enabled", True):
            _start_extra(config)
        else:
            _install_extra_service(config)
    except Exception:
        _run(["systemctl", "stop", _extra_service(profile_id)], check=False)
        _write_extra_files(previous)
        try:
            _install_extra_service(previous)
            if previous.get("enabled", True):
                _start_extra(previous)
        except Exception:
            pass
        raise
    return config


def profile_rotate(profile_id):
    if profile_id == "main":
        return rotate_key()
    config = next((item for item in _extra_configs() if item["id"] == _extra_id(profile_id)), None)
    if config is None:
        raise OpenFluxError("Профиль OpenFlux не найден.")
    previous = dict(config)
    config["key"] = secrets.token_urlsafe(32)
    config["enabled"] = True
    config["updated_at"] = int(time.time())
    _write_extra_files(config)
    try:
        _start_extra(config)
    except Exception:
        _run(["systemctl", "stop", _extra_service(config["id"])], check=False)
        _write_extra_files(previous)
        try:
            if previous.get("enabled", True):
                _start_extra(previous)
        except Exception:
            pass
        raise


def delete_profile(profile_id):
    if profile_id == "main":
        config = _load()
        if not config.get("url"):
            raise OpenFluxError("Профиль OpenFlux не найден.")
        _run(["systemctl", "disable", "--now", SERVICE], check=False)
        for path in (STATE_FILE, URL_FILE, KEY_FILE, ENABLED_FILE):
            try:
                path.unlink()
            except FileNotFoundError:
                pass
        # Keep the unit template installed so a new main profile can be
        # created later without reinstalling the panel.
        install_service()
        return
    profile_id = _extra_id(profile_id)
    paths = _extra_paths(profile_id)
    if not paths["state"].exists():
        raise OpenFluxError("Профиль OpenFlux не найден.")
    _run(["systemctl", "disable", "--now", _extra_service(profile_id)], check=False)
    try:
        paths["unit"].unlink()
    except FileNotFoundError:
        pass
    shutil.rmtree(paths["dir"], ignore_errors=True)
    _run(["systemctl", "daemon-reload"], check=False)
