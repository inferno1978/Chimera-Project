#!/usr/bin/env bash
# Safe in-place updater for WEB PANEL PROXY V 2.9.1.
set -Eeuo pipefail
umask 077

WPP_PROGRESS_TTY=0 WPP_PROGRESS_ROWS=0 WPP_PROGRESS_LAST=-1 WPP_PROGRESS_ACTIVE=0
wpp_progress_start() {
    WPP_PROGRESS_ACTIVE=1
    if [[ -t 1 && "${TERM:-dumb}" != "dumb" ]] && command -v tput >/dev/null 2>&1; then
        WPP_PROGRESS_ROWS="$(tput lines 2>/dev/null || echo 0)"
        if (( WPP_PROGRESS_ROWS >= 6 )); then
            WPP_PROGRESS_TTY=1
            printf '\033[1;%dr\033[%d;1H' "$((WPP_PROGRESS_ROWS-1))" "$((WPP_PROGRESS_ROWS-1))"
        fi
    fi
    wpp_progress 0 "$1"
}
wpp_progress() {
    local percent="$1" label="$2" width=28 filled empty bar
    (( percent < 0 )) && percent=0; (( percent > 100 )) && percent=100
    if [[ "${WPP_WEB_UPDATE:-0}" == 1 ]]; then printf 'WPP_PANEL_PROGRESS %d %s\n' "$percent" "$label"; fi
    filled=$((percent*width/100)); empty=$((width-filled))
    printf -v bar '%*s' "$filled" ''; bar="${bar// /#}"
    printf -v empty '%*s' "$empty" ''; bar+="${empty// /-}"
    if (( WPP_PROGRESS_TTY )); then
        printf '\0337\033[%d;1H\033[2K[%s] %3d%%  %s\0338' "$WPP_PROGRESS_ROWS" "$bar" "$percent" "$label"
    elif (( percent != WPP_PROGRESS_LAST )); then printf '[%s] %3d%%  %s\n' "$bar" "$percent" "$label"; fi
    WPP_PROGRESS_LAST="$percent"
}
wpp_progress_finish() {
    local code="$1"
    (( WPP_PROGRESS_ACTIVE )) || return 0
    if (( code == 0 )); then wpp_progress 100 "Обновление завершено"; else wpp_progress "$WPP_PROGRESS_LAST" "Обновление прервано"; fi
    if (( WPP_PROGRESS_TTY )); then
        printf '\0337\033[%d;1H\033[2K\0338\033[r\033[%d;1H' "$WPP_PROGRESS_ROWS" "$WPP_PROGRESS_ROWS"
        printf '[############################] %3d%%  %s\n' "$([[ $code == 0 ]] && echo 100 || echo "$WPP_PROGRESS_LAST")" "$([[ $code == 0 ]] && echo 'Обновление завершено' || echo 'Обновление прервано')"
    fi
}

# Use the fixed public repository without interactive credentials or local
# Git URL substitutions.
export GIT_TERMINAL_PROMPT=0
export GIT_CONFIG_NOSYSTEM=1
export GIT_CONFIG_GLOBAL=/dev/null

REPOSITORY="https://github.com/POLESNIESOVETI12/web-panel-proxy.git"
REQUESTED_REF="${WEB_PANEL_PROXY_REF:-}"
RELEASE_REF="$REQUESTED_REF"
LOCAL_SOURCE=""
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONTROLLER_VERSION="3.0.0-alpha49"
CONTROLLER_REVISION=2026112001
CONTROLLER_DIR=/usr/local/lib/web-panel-proxy-updater
CONTROLLER_ENTRY=/usr/local/sbin/web-panel-proxy-update
CONTROLLER_UNINSTALL=/usr/local/sbin/web-panel-proxy-uninstall
SELECTED_RELEASE_SHA=""
if [[ "${1:-}" == --ref && $# == 2 ]]; then
    REQUESTED_REF="$2"
    RELEASE_REF="$REQUESTED_REF"
    shift 2
fi

# WPP_GITHUB_RELEASE_BEGIN
git_release() {
    GIT_TERMINAL_PROMPT=0 GIT_ASKPASS=/bin/false \
    GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_COUNT=0 \
        git -c credential.helper= "$@"
}
fetch_github_release() {
    local destination="$1" tag="$2" refs expected actual
    [[ "$tag" =~ ^v[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9.-]+)?$ ]] || die "Invalid GitHub release tag."
    refs="$(git_release ls-remote --exit-code "$REPOSITORY" "refs/tags/$tag" "refs/tags/$tag^{}")" ||
        die "Could not read the selected release tag from GitHub."
    expected="$(printf '%s\n' "$refs" | awk -v ref="refs/tags/$tag" '$2==ref {base=$1} $2==ref"^{}" {peeled=$1} END {print peeled?peeled:base}')"
    [[ "$expected" =~ ^[0-9a-f]{40}$ ]] || die "GitHub release commit is missing or invalid."
    git_release -c init.defaultBranch=main init -q "$destination"
    git_release -C "$destination" remote add origin "$REPOSITORY"
    git_release -C "$destination" fetch --no-tags --depth 1 origin "refs/tags/$tag"
    git_release -C "$destination" checkout --detach --force "$expected"
    actual="$(git_release -C "$destination" rev-parse HEAD)"
    [[ "$actual" == "$expected" ]] || die "Downloaded release does not match the GitHub tag."
    SELECTED_RELEASE_SHA="$actual"
    printf 'WPP_RELEASE_SOURCE GitHub %s %s\n' "$tag" "$actual"
}
# WPP_GITHUB_RELEASE_END

# WPP_CONTROLLER_BUNDLE_BEGIN
stage_update_controller() {
    local candidate version revision current_compare candidate_compare file source use_candidate=0
    candidate="$TEMP_DIR/source/update.sh"
    version="$(sed -n 's/^CONTROLLER_VERSION="\([0-9A-Za-z.+-]*\)"$/\1/p' "$candidate" | head -n1)"
    revision="$(sed -n 's/^CONTROLLER_REVISION=\([0-9]*\)$/\1/p' "$candidate" | head -n1)"
    # The recovery controller has its own revision. An older helper packaged
    # with a higher panel version must not replace the fixed controller.
    if [[ "$revision" =~ ^[0-9]{1,12}$ ]]; then
        if (( 10#$revision >= CONTROLLER_REVISION )); then use_candidate=1; fi
    elif [[ "${CONTROLLER_REVISION:-0}" == 0 && "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+([.-](alpha|beta|rc)[0-9]+)?$ ]]; then
        current_compare="$(sed -E 's/[.-](alpha|beta|rc)([0-9]+)$/~\1\2/' <<<"$CONTROLLER_VERSION")"
        candidate_compare="$(sed -E 's/[.-](alpha|beta|rc)([0-9]+)$/~\1\2/' <<<"$version")"
        dpkg --compare-versions "$candidate_compare" ge "$current_compare" && use_candidate=1
    fi
    install -d -m 0700 "$TEMP_DIR/controller"
    if [[ "$use_candidate" == 1 ]]; then
        cp -- "$candidate" "$TEMP_DIR/controller/update.sh"
    else
        cp -- "$0" "$TEMP_DIR/controller/update.sh"
    fi
    for file in wpp_update_data.py wpp_update.py wpp_metrics.py uninstall-web-proxy.sh; do
        if [[ "$use_candidate" == 1 ]]; then source="$TEMP_DIR/source/$file"
        elif [[ -s "$SCRIPT_DIR/$file" ]]; then source="$SCRIPT_DIR/$file"
        elif [[ -s "$CONTROLLER_DIR/$file" ]]; then source="$CONTROLLER_DIR/$file"
        elif [[ "$file" == uninstall-web-proxy.sh ]]; then source="$CONTROLLER_UNINSTALL"
        else source="/opt/tproxy-panel/$file"; fi
        if [[ ! -s "$source" && "$file" == uninstall-web-proxy.sh ]]; then source="$TEMP_DIR/source/$file"; fi
        [[ -s "$source" ]] || die "Version controller is incomplete: $file"
        cp -- "$source" "$TEMP_DIR/controller/$file"
    done
}
install_update_controller() {
    local file
    install -d -o root -g root -m 0700 "$CONTROLLER_DIR"
    for file in update.sh wpp_update_data.py wpp_update.py wpp_metrics.py uninstall-web-proxy.sh; do
        install -o root -g root -m 0600 "$TEMP_DIR/controller/$file" "$CONTROLLER_DIR/$file"
    done
    install -o root -g root -m 0755 "$TEMP_DIR/controller/update.sh" "$CONTROLLER_ENTRY"
    install -o root -g root -m 0755 "$TEMP_DIR/controller/uninstall-web-proxy.sh" "$CONTROLLER_UNINSTALL"
}
# WPP_CONTROLLER_BUNDLE_END

# WPP_RELAY_UMASK_COMPAT_BEGIN
prepare_relay_repair() {
    # Old tags carry the pre-fix launcher. Change only that temporary wrapper;
    # the pinned relay source, tests and production permissions stay intact.
    python3 - "$1" <<'PY'
from pathlib import Path
import re,sys
path=Path(sys.argv[1])
source=path.read_text(encoding='utf-8')
call='bash "$WORK/source/deploy/update-relay.sh"'
safe='(\n    umask 022\n    '+call+'\n)'
if safe not in source:
    pattern=r'(?m)^([ \t]*)bash "\$WORK/source/deploy/update-relay\.sh"[ \t]*$'
    matches=list(re.finditer(pattern,source))
    if len(matches)>1:
        raise SystemExit('Cannot safely prepare relay updater: ambiguous launcher.')
    if matches:
        match=matches[0];indent=match[1]
        replacement=indent+'(\n'+indent+'    umask 022\n'+indent+'    '+call+'\n'+indent+')'
        source=source[:match.start()]+replacement+source[match.end():]
        with path.open('w',encoding='utf-8',newline='\n') as stream:stream.write(source)
        print('Applied relay test permission compatibility fix to the downloaded wrapper.')
PY
}
# WPP_RELAY_UMASK_COMPAT_END

# WPP_PANEL_RELEASE_PREPARE_BEGIN
prepare_panel_release() {
    wpp_progress 50 "Проверка выбранной версии"
    if [[ "$MIGRATING_LEGACY" != 1 ]]; then
        echo "Existing relay retained. Installing only the selected panel release; relay rebuild is not part of version switching."
        return 0
    fi
    # A first-generation installation still needs the public-site migration.
    if [[ -f "$TEMP_DIR/source/repair-landing-pages.sh" ]]; then
        prepare_relay_repair "$TEMP_DIR/source/repair-landing-pages.sh"
        chmod 0700 "$TEMP_DIR/source/repair-landing-pages.sh"
        bash "$TEMP_DIR/source/repair-landing-pages.sh"
    fi
}
# WPP_PANEL_RELEASE_PREPARE_END


# A complete extracted ZIP is itself the requested release. Prefer it
# automatically so `bash ./update.sh` never falls back to an older public tag.
AUTO_LOCAL=0
if [[ -z "$REQUESTED_REF" && $# == 0 && -s "$SCRIPT_DIR/install-panel.sh" && -s "$SCRIPT_DIR/wpp_ui.py" &&
      -s "$SCRIPT_DIR/assets/amneziawg-go-linux-amd64" ]]; then
    AUTO_LOCAL=1
fi
if [[ "${1:-}" == "--local" || "$AUTO_LOCAL" == 1 ]]; then
    LOCAL_SOURCE="$SCRIPT_DIR"
    RELEASE_REF="v2.9.1"
    for file in install-panel.sh update.sh uninstall-web-proxy.sh repair-landing-pages.sh panel-logo.png THIRD-PARTY-NOTICES.md wpp_subscriptions.py wpp_subscription_dashboard.py wpp_panel_extras.py wpp_ui.py wpp_metrics.py wpp_update.py wpp_update_data.py wpp_nodes.py wpp_openflux.py wpp_awg.py wpp_extra_protocols.py wpp_firewall.py wpp_components.py wpp_cdn.py wpp_cdn_doctor.py wpp_connections.py wpp_backup.py wpp_routing.py wpp_presets.py wpp_cascade.py wpp_cascade_ui.py wpp_ssh_cascade.py wpp_ssh_cascade_ui.py wpp_ssh_relay_agent.py wpp_cascade_ops.py wpp_cascade_ops_ui.py frontend/cascade/editor.css frontend/cascade/editor.html frontend/cascade/production.js frontend/cascade/methods.css frontend/cascade/methods.html frontend/cascade/methods.js; do
        [[ -s "$LOCAL_SOURCE/$file" ]] || { echo "Incomplete local archive: $file is missing." >&2; exit 1; }
    done
    [[ -s "$LOCAL_SOURCE/assets/OpenFlux-linux-amd64" || -s "$LOCAL_SOURCE/OpenFlux-linux-amd64" ]] || {
        echo "Incomplete local archive: OpenFlux-linux-amd64 is missing." >&2; exit 1;
    }
    for file in mtproxy-download.sh assets/mtproxy-bootstrap/proxy-secret assets/mtproxy-bootstrap/proxy-multi.conf; do
        [[ -s "$LOCAL_SOURCE/$file" ]] || { echo "Incomplete archive: $file is missing." >&2; exit 1; }
    done
    for file in amneziawg-go-linux-amd64 awg-linux-amd64 awg-quick-linux-amd64; do
        [[ -s "$LOCAL_SOURCE/assets/$file" ]] || {
            echo "Incomplete local archive: assets/$file is missing." >&2; exit 1;
        }
    done
    for file in caddy-forwardproxy-naive-v2.11.7-naive2.tar.xz mita-v3.39.0-linux-amd64.tar.gz mieru-v3.39.0-source.tar.gz; do
        [[ -s "$LOCAL_SOURCE/assets/$file" ]] || { echo "Incomplete local archive: assets/$file is missing." >&2; exit 1; }
    done
    [[ -s "$LOCAL_SOURCE/wpp-panel/flags.tar.gz" ]] || {
        echo "Incomplete local archive: wpp-panel/flags.tar.gz is missing." >&2; exit 1;
    }
    for file in preset-cars.webp preset-car-graphite.webp preset-car-silver.webp preset-car-white.webp preset-car-blue.webp preset-car-red.webp preset-car-black.webp preset-coffee.webp awg-routing-guide.mp4; do
        [[ -s "$LOCAL_SOURCE/assets/$file" ]] || {
            echo "Incomplete local archive: assets/$file is missing." >&2; exit 1;
        }
    done
elif [[ $# != 0 ]]; then
    echo "Usage: bash update.sh [--local | --ref vX.Y.Z]" >&2; exit 1
fi
SERVICE="/etc/systemd/system/tproxy-panel.service"
LEGACY_SERVICE="/etc/systemd/system/web-proxy-panel.service"
DATA_FILE="/var/lib/tproxy-panel/data.json"
PRIMARY_SECRET="/etc/web-proxy-panel/primary-secret"

die() { echo "ERROR: $*" >&2; exit 1; }
[[ ${EUID} -eq 0 ]] || die "Run as root: sudo -i"
command -v flock >/dev/null 2>&1 || die "flock is required (package: util-linux)."
exec 9>/run/lock/web-panel-proxy.lock
flock -n 9 || die "Another WEB PANEL PROXY install, update or removal is already running."

echo "============================================================"
echo "     WEB PANEL PROXY V 2.9.1 — SAFE UPDATE"
echo "============================================================"
echo "Users, administrator password, panel URL and site HTML will be retained."
wpp_progress_start "Проверка установленной версии"

MIGRATING_LEGACY=0
PANEL_PATH=""
LEGACY_SECRET=""

if [[ -s "$DATA_FILE" ]] &&
   { [[ -f "$SERVICE" ]] || [[ -f "$LEGACY_SERVICE" ]]; }; then
    echo "Current control panel detected; account and data will be preserved."
else
    for legacy_item in /etc/tproxy-server/config.json /etc/tproxy-server/profiles.json /etc/mtproxy /opt/MTProxy /etc/systemd/system/mtproxy.service /etc/systemd/system/tproxy-server.service; do
        if [[ -e "$legacy_item" ]]; then
            MIGRATING_LEGACY=1
            break
        fi
    done
    [[ "$MIGRATING_LEGACY" == 1 ]] || die "No supported WEB Proxy installation was found."
    echo "First-generation WEB Proxy detected (without a control panel)."
    echo "The updater will add the panel and ask for a new administrator login and password."
fi

# Some early builds used this service name. Copying it only supplies the
# existing secret panel address; install-panel.sh replaces the definition.
if [[ "$MIGRATING_LEGACY" != 1 && ! -f "$SERVICE" && -f "$LEGACY_SERVICE" ]]; then
    cp -a "$LEGACY_SERVICE" "$SERVICE"
fi
if [[ "$MIGRATING_LEGACY" != 1 ]]; then
    [[ -f "$SERVICE" ]] || die "Panel service file was not found."
    PANEL_PATH="$(sed -n 's/^Environment=WEBPROXY_PANEL_PATH=//p' "$SERVICE" | head -n1 || true)"
    [[ "$PANEL_PATH" =~ ^/panel-[a-z0-9-]{3,64}$ ]] || die "Could not read the existing panel address."
fi

if [[ "$MIGRATING_LEGACY" == 1 ]]; then
    LEGACY_SECRET="$(cat "$PRIMARY_SECRET" 2>/dev/null || true)"
    if ! [[ "$LEGACY_SECRET" =~ ^([0-9a-f]{32}|dd[0-9a-f]{32})$ ]] && [[ -s /etc/tproxy-server/profiles.json ]]; then
        LEGACY_SECRET="$(sed -n 's/.*"secret"[[:space:]]*:[[:space:]]*"\([0-9a-f]*\)".*/\1/p' /etc/tproxy-server/profiles.json | head -n1)"
    fi
    if ! [[ "$LEGACY_SECRET" =~ ^([0-9a-f]{32}|dd[0-9a-f]{32})$ ]] && [[ -s /etc/mtproxy/mtproxy.env ]]; then
        LEGACY_SECRET="$(sed -n 's/^MTPROXY_SECRET=//p' /etc/mtproxy/mtproxy.env | head -n1)"
    fi
    if ! [[ "$LEGACY_SECRET" =~ ^([0-9a-f]{32}|dd[0-9a-f]{32})$ ]]; then
        # The first public installer stored the Secret only in ExecStart=-S.
        LEGACY_SECRET="$(systemctl cat mtproxy.service 2>/dev/null |
            sed -n 's/.*[[:space:]]-S[[:space:]]\([0-9a-f]*\).*/\1/p' | head -n1 || true)"
    fi
    [[ "$LEGACY_SECRET" =~ ^([0-9a-f]{32}|dd[0-9a-f]{32})$ ]] ||
        die "Could not recover the primary Secret from the first-generation installation."
else
    [[ -s "$PRIMARY_SECRET" ]] || die "Primary Secret is missing from the existing panel installation."
fi

TRAFFIC_WAS_RUNNING=0
systemctl is-active --quiet web-proxy-panel-traffic.timer && TRAFFIC_WAS_RUNNING=1
systemctl stop web-proxy-panel-traffic.timer web-proxy-panel-traffic.service 2>/dev/null || true
CASCADE_WAS_RUNNING=0
systemctl is-active --quiet web-panel-proxy-cascade-monitor.timer && CASCADE_WAS_RUNNING=1
systemctl stop web-panel-proxy-cascade-monitor.timer web-panel-proxy-cascade-monitor.service 2>/dev/null || true
# Pause the HTTP writer before taking a snapshot of subscription slots/keys.
# Proxy services keep running. Recover the panel if snapshot/download fails.
PANEL_WAS_RUNNING=0
if systemctl is-active --quiet tproxy-panel.service; then
    PANEL_WAS_RUNNING=1
    systemctl stop tproxy-panel.service
fi
BACKUP="$(mktemp -d /tmp/web-panel-proxy-rollback.XXXXXX)"
chmod 0700 "$BACKUP"
early_finish() { local code=$?; if [[ "$TRAFFIC_WAS_RUNNING" == 1 ]]; then systemctl start web-proxy-panel-traffic.timer || true; fi; if [[ "$CASCADE_WAS_RUNNING" == 1 ]]; then systemctl start web-panel-proxy-cascade-monitor.timer || true; fi; if [[ "$PANEL_WAS_RUNNING" == 1 ]]; then systemctl start tproxy-panel.service || true; fi; rm -rf -- "${BACKUP:-}"; wpp_progress_finish "$code"; }
trap early_finish EXIT
BACKUP_ITEMS=()
for item in /usr/local/lib/web-panel-proxy-updater /usr/local/sbin/web-panel-proxy-update /opt/tproxy-panel /opt/web-panel-proxy /opt/MTProxy /usr/local/bin/caddy /usr/local/bin/tproxy-server /usr/local/bin/amneziawg-go /usr/local/bin/awg /usr/local/bin/awg-quick /usr/local/sbin/web-proxy-panelctl /usr/local/sbin/web-proxy-panel-user-firewall /usr/local/sbin/web-panel-proxy-sync-tls /usr/local/sbin/web-panel-proxy-awg-run /usr/local/sbin/web-panel-proxy-awg-up /usr/local/sbin/web-panel-proxy-awg-down /usr/local/sbin/web-proxy-panel-update /usr/local/sbin/web-panel-proxy-uninstall /usr/local/sbin/WPP /usr/local/sbin/wpp /etc/systemd/system/tproxy-panel.service /etc/systemd/system/tproxy-panel.service.d/go-runtime.conf /etc/systemd/system/web-panel-proxy-web-update.service.d/go-runtime.conf /etc/systemd/system/web-panel-proxy-auto-update.service.d/go-runtime.conf /etc/systemd/system/web-panel-proxy-awg@.service.d/go-runtime.conf /etc/systemd/system/web-proxy-panel-firewall.service /etc/systemd/system/web-proxy-panel-traffic.service /etc/systemd/system/web-proxy-panel-traffic.timer /etc/systemd/system/web-panel-proxy-xray.service /etc/systemd/system/web-panel-proxy-openflux.service /etc/systemd/system/web-panel-proxy-awg@.service /etc/systemd/system/web-panel-proxy-sync-tls.service /etc/systemd/system/web-panel-proxy-sync-tls.timer /etc/systemd/system/web-panel-proxy-component-update.service /etc/systemd/system/tproxy-server.service /etc/systemd/system/mtproxy.service /etc/systemd/system/caddy.service.d/tproxy.conf /etc/caddy/Caddyfile /etc/tproxy-server /etc/mtproxy /etc/mita /etc/web-panel-proxy-xray /etc/sysctl.d/90-web-panel-proxy-awg.conf /var/lib/web-panel-proxy-xray /var/lib/web-panel-proxy-components /var/lib/tproxy-panel /etc/web-proxy-panel /srv/tproxy-site; do
    [[ -e "$item" ]] && BACKUP_ITEMS+=("$item")
    [[ -e "$item" ]] && cp -a --parents "$item" "$BACKUP"
done
for item in /usr/local/bin/caddy-naive /usr/local/bin/mita-wpp /etc/systemd/system/web-panel-proxy-naive.service /etc/systemd/system/web-panel-proxy-mieru.service /etc/systemd/system/web-panel-proxy-mieru@.service; do
    [[ -e "$item" ]] || continue
    BACKUP_ITEMS+=("$item")
    cp -a --parents "$item" "$BACKUP"
done
shopt -s nullglob
for item in /etc/systemd/system/web-proxy-user-*.service /etc/systemd/system/web-panel-proxy-web-update.service /etc/systemd/system/web-panel-proxy-auto-update.service /etc/systemd/system/web-panel-proxy-auto-update.timer /etc/systemd/system/web-panel-proxy-metrics.service /etc/systemd/system/web-panel-proxy-metrics.timer /etc/systemd/system/web-panel-proxy-cascade-monitor.service /etc/systemd/system/web-panel-proxy-cascade-monitor.timer /etc/systemd/system/web-panel-proxy-smartdns.service; do
    [[ -e "$item" ]] || continue
    BACKUP_ITEMS+=("$item")
    cp -a --parents "$item" "$BACKUP"
done
shopt -u nullglob
tar --numeric-owner -cpf "$BACKUP/state.tar" "${BACKUP_ITEMS[@]}"
echo "Temporary rollback snapshot prepared. It will be deleted automatically."
wpp_progress 15 "Временный откат подготовлен"

# The experimental 3.0 Go cutover used systemd drop-ins to replace the Python
# commands.  A normal Python release must remove those overrides; otherwise
# systemd keeps starting the old Go binary even though every panel file was
# successfully updated.  The files are already in the rollback snapshot above.
GO_RUNTIME_DROPINS=(
    /etc/systemd/system/tproxy-panel.service.d/go-runtime.conf
    /etc/systemd/system/web-panel-proxy-web-update.service.d/go-runtime.conf
    /etc/systemd/system/web-panel-proxy-auto-update.service.d/go-runtime.conf
    /etc/systemd/system/web-panel-proxy-awg@.service.d/go-runtime.conf
)
GO_RUNTIME_REMOVED=0
for dropin in "${GO_RUNTIME_DROPINS[@]}"; do
    if [[ -e "$dropin" ]]; then
        rm -f -- "$dropin"
        GO_RUNTIME_REMOVED=1
    fi
done
if [[ "$GO_RUNTIME_REMOVED" == 1 ]]; then
    systemctl daemon-reload
    echo "Experimental Go runtime overrides disabled; returning to the Python panel."
fi

HAD_FIREWALL_SERVICE=0
[[ -e /etc/systemd/system/web-proxy-panel-firewall.service ]] && HAD_FIREWALL_SERVICE=1
HAD_TRAFFIC_TIMER=0
[[ -e /etc/systemd/system/web-proxy-panel-traffic.timer ]] && HAD_TRAFFIC_TIMER=1
HAD_SMARTDNS_USER=0
HAD_SMARTDNS_GROUP=0
id wpp-smartdns >/dev/null 2>&1 && HAD_SMARTDNS_USER=1
getent group wpp-smartdns >/dev/null 2>&1 && HAD_SMARTDNS_GROUP=1
HAD_SMARTDNS_UNIT=0
[[ -e /etc/systemd/system/web-panel-proxy-smartdns.service ]] && HAD_SMARTDNS_UNIT=1
HAD_CASCADE_TIMER=0
[[ -e /etc/systemd/system/web-panel-proxy-cascade-monitor.timer ]] && HAD_CASCADE_TIMER=1
HAD_METRICS_TIMER=0
[[ -e /etc/systemd/system/web-panel-proxy-metrics.timer ]] && HAD_METRICS_TIMER=1
HAD_PANEL_DATA=0
HAD_PANEL_SERVICE=0
HAD_PRIMARY_SECRET=0
HAD_CADDY_DROPIN=0
HAD_PANEL_STATE_DIR=0
HAD_XRAY_STATE=0
HAD_XRAY_USER=0
HAD_XRAY_GROUP=0
HAD_MITA_USER=0
HAD_MITA_GROUP=0
HAD_OPENFLUX_UNIT=0
HAD_OPENFLUX_USER=0
HAD_AWG=0
HAD_EXTRA_PROTOCOLS=0
HAD_WPP_MENU=0
HAD_WEB_UPDATE_UNIT=0
[[ -e /etc/systemd/system/web-panel-proxy-web-update.service ]] && HAD_WEB_UPDATE_UNIT=1
HAD_AUTO_UPDATE_UNITS=0
[[ -e /etc/systemd/system/web-panel-proxy-auto-update.service && -e /etc/systemd/system/web-panel-proxy-auto-update.timer ]] && HAD_AUTO_UPDATE_UNITS=1
HAD_COMPONENT_UPDATE_UNIT=0
[[ -e /etc/systemd/system/web-panel-proxy-component-update.service ]] && HAD_COMPONENT_UPDATE_UNIT=1
[[ -e "$DATA_FILE" ]] && HAD_PANEL_DATA=1
[[ -e "$SERVICE" ]] && HAD_PANEL_SERVICE=1
[[ -e "$PRIMARY_SECRET" ]] && HAD_PRIMARY_SECRET=1
[[ -e /etc/systemd/system/caddy.service.d/tproxy.conf ]] && HAD_CADDY_DROPIN=1
[[ -d /etc/web-proxy-panel ]] && HAD_PANEL_STATE_DIR=1
{ [[ -e /opt/web-panel-proxy ]] || [[ -e /etc/web-panel-proxy-xray ]] || [[ -e /etc/systemd/system/web-panel-proxy-xray.service ]]; } && HAD_XRAY_STATE=1
id xray >/dev/null 2>&1 && HAD_XRAY_USER=1
getent group xray >/dev/null 2>&1 && HAD_XRAY_GROUP=1
id mita >/dev/null 2>&1 && HAD_MITA_USER=1
getent group mita >/dev/null 2>&1 && HAD_MITA_GROUP=1
[[ -e /etc/systemd/system/web-panel-proxy-openflux.service ]] && HAD_OPENFLUX_UNIT=1
id wpp-openflux >/dev/null 2>&1 && HAD_OPENFLUX_USER=1
[[ -e /etc/systemd/system/web-panel-proxy-awg@.service || -x /usr/local/bin/amneziawg-go ]] && HAD_AWG=1
[[ -e /etc/systemd/system/web-panel-proxy-naive.service || -e /etc/systemd/system/web-panel-proxy-mieru.service || -e /etc/systemd/system/web-panel-proxy-mieru@.service ]] && HAD_EXTRA_PROTOCOLS=1
[[ -e /usr/local/sbin/WPP ]] && HAD_WPP_MENU=1
HAD_UPDATE_CONTROLLER=0
[[ -d "$CONTROLLER_DIR" ]] && HAD_UPDATE_CONTROLLER=1
HAD_UPDATE_ENTRY=0
[[ -e "$CONTROLLER_ENTRY" ]] && HAD_UPDATE_ENTRY=1
HAD_UPDATE_UNINSTALL=0
[[ -e "$CONTROLLER_UNINSTALL" ]] && HAD_UPDATE_UNINSTALL=1
HAD_VERSION_DATA=0
[[ -e /etc/web-proxy-panel/version-data.json ]] && HAD_VERSION_DATA=1
UPDATE_COMMITTED=0
rollback_update() {
    local code="$1"
    [[ "$UPDATE_COMMITTED" == 1 || "$code" == 0 ]] && return 0
    echo "Update failed; restoring the previous working state..." >&2
    systemctl stop web-panel-proxy-smartdns.service web-panel-proxy-cascade-monitor.timer web-panel-proxy-cascade-monitor.service tproxy-panel.service web-proxy-panel-firewall.service web-proxy-panel-traffic.timer web-proxy-panel-traffic.service web-panel-proxy-metrics.timer web-panel-proxy-metrics.service web-panel-proxy-xray.service web-panel-proxy-openflux.service web-panel-proxy-naive.service web-panel-proxy-mieru.service web-panel-proxy-sync-tls.timer web-panel-proxy-auto-update.timer web-panel-proxy-auto-update.service 2>/dev/null || true
    for unit in $(systemctl list-units --all 'web-panel-proxy-awg@*.service' --no-legend 2>/dev/null | awk '{print $1}'); do systemctl stop "$unit" 2>/dev/null || true; done
    for unit in $(systemctl list-units --all 'web-panel-proxy-mieru@*.service' --no-legend 2>/dev/null | awk '{print $1}'); do systemctl stop "$unit" 2>/dev/null || true; done
    tar --numeric-owner -xpf "$BACKUP/state.tar" -C / 2>/dev/null || true
    [[ "$HAD_VERSION_DATA" == 1 ]] || rm -f -- /etc/web-proxy-panel/version-data.json
    [[ "$HAD_UPDATE_CONTROLLER" == 1 ]] || rm -rf -- /usr/local/lib/web-panel-proxy-updater
    [[ "$HAD_UPDATE_ENTRY" == 1 ]] || rm -f -- /usr/local/sbin/web-panel-proxy-update
    [[ "$HAD_UPDATE_UNINSTALL" == 1 ]] || rm -f -- /usr/local/sbin/web-panel-proxy-uninstall
    if [[ "$HAD_FIREWALL_SERVICE" == 0 ]]; then
        rm -f /etc/systemd/system/web-proxy-panel-firewall.service
        rm -f /usr/local/sbin/web-proxy-panel-user-firewall
    fi
    if [[ "$HAD_TRAFFIC_TIMER" == 0 ]]; then
        rm -f /etc/systemd/system/web-proxy-panel-traffic.service /etc/systemd/system/web-proxy-panel-traffic.timer
    fi
    if [[ "$HAD_SMARTDNS_USER" == 0 ]]; then userdel wpp-smartdns 2>/dev/null || true; fi
    if [[ "$HAD_SMARTDNS_GROUP" == 0 ]]; then groupdel wpp-smartdns 2>/dev/null || true; fi
    if [[ "$HAD_SMARTDNS_UNIT" == 0 ]]; then
        systemctl disable web-panel-proxy-smartdns.service 2>/dev/null || true
        rm -f /etc/systemd/system/web-panel-proxy-smartdns.service
    fi
    if [[ "$HAD_CASCADE_TIMER" == 0 ]]; then
        systemctl disable web-panel-proxy-cascade-monitor.timer 2>/dev/null || true
        rm -f /etc/systemd/system/web-panel-proxy-cascade-monitor.service /etc/systemd/system/web-panel-proxy-cascade-monitor.timer
    fi
    if [[ "$HAD_METRICS_TIMER" == 0 ]]; then
        systemctl disable web-panel-proxy-metrics.timer 2>/dev/null || true
        rm -f /etc/systemd/system/web-panel-proxy-metrics.service /etc/systemd/system/web-panel-proxy-metrics.timer
    fi
    if [[ "$HAD_WPP_MENU" == 0 ]]; then
        rm -f /usr/local/sbin/WPP /usr/local/sbin/wpp /usr/local/sbin/web-panel-proxy-update
    fi
    if [[ "$HAD_WEB_UPDATE_UNIT" == 0 ]]; then
        rm -f /etc/systemd/system/web-panel-proxy-web-update.service
    fi
    if [[ "$HAD_AUTO_UPDATE_UNITS" == 0 ]]; then
        systemctl disable web-panel-proxy-auto-update.timer 2>/dev/null || true
        rm -f /etc/systemd/system/web-panel-proxy-auto-update.service /etc/systemd/system/web-panel-proxy-auto-update.timer
    fi
    if [[ "$HAD_COMPONENT_UPDATE_UNIT" == 0 ]]; then
        rm -f /etc/systemd/system/web-panel-proxy-component-update.service
        rm -rf /var/lib/web-panel-proxy-components
    fi
    if [[ "$HAD_PANEL_SERVICE" == 0 ]]; then
        rm -f "$SERVICE"
        rm -rf /opt/tproxy-panel
    fi
    if [[ "$HAD_PANEL_DATA" == 0 ]]; then
        rm -rf /var/lib/tproxy-panel
    fi
    if [[ "$HAD_PRIMARY_SECRET" == 0 ]]; then
        rm -f "$PRIMARY_SECRET"
    fi
    if [[ "$HAD_PANEL_STATE_DIR" == 0 ]]; then
        rm -rf /etc/web-proxy-panel
    fi
    if [[ "$HAD_CADDY_DROPIN" == 0 ]]; then
        rm -f /etc/systemd/system/caddy.service.d/tproxy.conf
    fi
    if [[ "$HAD_XRAY_STATE" == 0 ]]; then
        rm -rf /opt/web-panel-proxy /etc/web-panel-proxy-xray /var/lib/web-panel-proxy-xray
        rm -f /etc/web-proxy-panel/xray-path /etc/web-proxy-panel/xray-user-owned /etc/web-proxy-panel/xray-group-owned \
            /etc/web-proxy-panel/hysteria-ufw-owned
        rm -f /usr/local/sbin/web-panel-proxy-sync-tls \
            /etc/systemd/system/web-panel-proxy-xray.service \
            /etc/systemd/system/web-panel-proxy-sync-tls.service \
            /etc/systemd/system/web-panel-proxy-sync-tls.timer
    fi
    if [[ "$HAD_XRAY_USER" == 0 ]]; then
        userdel xray 2>/dev/null || true
    fi
    if [[ "$HAD_XRAY_GROUP" == 0 ]]; then
        groupdel xray 2>/dev/null || true
    fi
    if [[ "$HAD_MITA_USER" == 0 ]]; then
        rm -rf -- /var/lib/mita
        userdel mita 2>/dev/null || true
        rm -f /etc/web-proxy-panel/mita-user-owned
    fi
    if [[ "$HAD_MITA_GROUP" == 0 ]]; then
        groupdel mita 2>/dev/null || true
        rm -f /etc/web-proxy-panel/mita-group-owned
    fi
    if [[ "$HAD_OPENFLUX_UNIT" == 0 ]]; then
        systemctl disable --now web-panel-proxy-openflux.service 2>/dev/null || true
        rm -f /etc/systemd/system/web-panel-proxy-openflux.service
        rm -rf /opt/web-panel-proxy/openflux
    fi
    if [[ "$HAD_OPENFLUX_USER" == 0 ]]; then
        userdel wpp-openflux 2>/dev/null || true
    fi
    if [[ "$HAD_AWG" == 0 ]]; then
        rm -f /usr/local/bin/amneziawg-go /usr/local/bin/awg /usr/local/bin/awg-quick \
            /usr/local/sbin/web-panel-proxy-awg-run /usr/local/sbin/web-panel-proxy-awg-up /usr/local/sbin/web-panel-proxy-awg-down \
            /etc/systemd/system/web-panel-proxy-awg@.service /etc/sysctl.d/90-web-panel-proxy-awg.conf
        rm -f /etc/systemd/system/multi-user.target.wants/web-panel-proxy-awg@*.service
        nft delete table ip web_proxy_awg 2>/dev/null || true
    fi
    if [[ "$HAD_EXTRA_PROTOCOLS" == 0 ]]; then
        rm -f /usr/local/bin/caddy-naive /usr/local/bin/mita-wpp \
            /etc/systemd/system/web-panel-proxy-naive.service /etc/systemd/system/web-panel-proxy-mieru.service /etc/systemd/system/web-panel-proxy-mieru@.service
        rm -f /etc/systemd/system/multi-user.target.wants/web-panel-proxy-naive.service \
            /etc/systemd/system/multi-user.target.wants/web-panel-proxy-mieru.service \
            /etc/systemd/system/multi-user.target.wants/web-panel-proxy-mieru@*.service
        rm -rf -- /etc/web-proxy-panel/extra-protocols
    fi
    systemctl daemon-reload
    [[ "$HAD_SMARTDNS_UNIT" == 1 ]] && systemctl start web-panel-proxy-smartdns.service 2>/dev/null || true
    systemctl restart mtproxy.service tproxy-server.service caddy.service tproxy-panel.service 2>/dev/null || true
    [[ -e /etc/web-proxy-panel/openflux/enabled ]] && systemctl restart web-panel-proxy-openflux.service 2>/dev/null || true
    [[ "$HAD_FIREWALL_SERVICE" == 1 ]] && systemctl restart web-proxy-panel-firewall.service 2>/dev/null || true
    [[ "$HAD_XRAY_STATE" == 1 ]] && systemctl restart web-panel-proxy-xray.service 2>/dev/null || true
    if [[ "$HAD_AWG" == 1 ]]; then
        for unit in $(systemctl list-unit-files 'web-panel-proxy-awg@*.service' --no-legend 2>/dev/null | awk '$2=="enabled" {print $1}'); do
            systemctl restart "$unit" 2>/dev/null || true
        done
    fi
    if [[ "$HAD_EXTRA_PROTOCOLS" == 1 ]]; then
        systemctl is-enabled --quiet web-panel-proxy-naive.service 2>/dev/null && systemctl restart web-panel-proxy-naive.service 2>/dev/null || true
        systemctl is-enabled --quiet web-panel-proxy-mieru.service 2>/dev/null && systemctl restart web-panel-proxy-mieru.service 2>/dev/null || true
        for unit in $(systemctl list-unit-files 'web-panel-proxy-mieru@*.service' --no-legend 2>/dev/null | awk '$2=="enabled" {print $1}'); do
            systemctl restart "$unit" 2>/dev/null || true
        done
    fi
    [[ "$HAD_TRAFFIC_TIMER" == 1 ]] && systemctl restart web-proxy-panel-traffic.timer 2>/dev/null || true
    [[ "$HAD_CASCADE_TIMER" == 1 ]] && systemctl enable --now web-panel-proxy-cascade-monitor.timer 2>/dev/null || true
    [[ "$HAD_METRICS_TIMER" == 1 ]] && systemctl restart web-panel-proxy-metrics.timer 2>/dev/null || true
    [[ "$HAD_AUTO_UPDATE_UNITS" == 1 ]] && systemctl enable --now web-panel-proxy-auto-update.timer 2>/dev/null || true
    if [[ -s "$TEMP_DIR/suspended-units" ]]; then
        while read -r enabled active unit; do
            if [[ "$enabled" == 1 ]]; then systemctl enable "$unit" 2>/dev/null || true
            else systemctl disable "$unit" 2>/dev/null || true; fi
            if [[ "$active" == 1 ]]; then systemctl start "$unit" 2>/dev/null || true
            else systemctl stop "$unit" 2>/dev/null || true; fi
        done < "$TEMP_DIR/suspended-units"
    fi
    echo "Previous files restored; the temporary snapshot will now be removed." >&2
}

if ! command -v git >/dev/null 2>&1; then
    echo "Installing Git (required to download the update)..."
    export DEBIAN_FRONTEND=noninteractive
    apt-get -o DPkg::Lock::Timeout=600 update
    apt-get -o DPkg::Lock::Timeout=600 install -y --no-install-recommends git
fi

if [[ -z "$LOCAL_SOURCE" ]]; then
if [[ -z "$RELEASE_REF" ]]; then
    echo "Checking the latest published WEB PANEL PROXY version..."
    RELEASE_REF="$(git ls-remote --tags --refs "$REPOSITORY" 'v[0-9]*' |
        awk -F/ '{print $3}' | grep -E '^v[0-9]+\.[0-9]+\.[0-9]+$' | sort -V | tail -n1)"
fi
[[ "$RELEASE_REF" =~ ^v[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9.-]+)?$ ]] ||
    die "Could not determine a valid published release tag."
echo "Selected release: $RELEASE_REF"
CURRENT_VERSION="$(cat /etc/web-proxy-panel/version 2>/dev/null || true)"
CURRENT_COMPARE="$(sed -E 's/[.-](alpha|beta|rc)([0-9]+)$/~\1\2/' <<<"$CURRENT_VERSION")"
TARGET_COMPARE="$(sed -E 's/[.-](alpha|beta|rc)([0-9]+)$/~\1\2/' <<<"${RELEASE_REF#v}")"
if [[ -z "$REQUESTED_REF" && "$CURRENT_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+([.+~-][A-Za-z0-9.+~-]+)?$ ]] &&
   dpkg --compare-versions "$CURRENT_COMPARE" ge "$TARGET_COMPARE"; then
    echo "WEB PANEL PROXY ${CURRENT_VERSION} is already the latest published stable version."
    exit 0
fi
fi

TEMP_DIR="$(mktemp -d /tmp/web-panel-proxy-update.XXXXXX)"
finish() {
    local code=$?
    trap - EXIT
    rollback_update "$code"
    rm -rf "$TEMP_DIR"
    rm -rf -- "$BACKUP"
    wpp_progress_finish "$code"
    exit "$code"
}
trap finish EXIT

echo "Downloading WEB PANEL PROXY files..."
wpp_progress 25 "Получение файлов обновления"
if [[ -n "$LOCAL_SOURCE" ]]; then
    install -d -m 0700 "$TEMP_DIR/source"
    install -d -m 0700 "$TEMP_DIR/source/assets"
    install -d -m 0700 "$TEMP_DIR/source/assets/mtproxy-bootstrap"
    for file in mtproxy-download.sh assets/mtproxy-bootstrap/proxy-secret assets/mtproxy-bootstrap/proxy-multi.conf; do
        cp -a "$LOCAL_SOURCE/$file" "$TEMP_DIR/source/$file"
    done
    install -d -m 0700 "$TEMP_DIR/source/frontend/cascade"
    for file in install-panel.sh update.sh uninstall-web-proxy.sh repair-landing-pages.sh panel-logo.png THIRD-PARTY-NOTICES.md wpp_subscriptions.py wpp_subscription_dashboard.py wpp_panel_extras.py wpp_ui.py wpp_metrics.py wpp_update.py wpp_update_data.py wpp_nodes.py wpp_openflux.py wpp_awg.py wpp_extra_protocols.py wpp_firewall.py wpp_components.py wpp_cdn.py wpp_cdn_doctor.py wpp_connections.py wpp_backup.py wpp_routing.py wpp_presets.py wpp_cascade.py wpp_cascade_ui.py wpp_ssh_cascade.py wpp_ssh_cascade_ui.py wpp_ssh_relay_agent.py wpp_cascade_ops.py wpp_cascade_ops_ui.py frontend/cascade/editor.css frontend/cascade/editor.html frontend/cascade/production.js frontend/cascade/methods.css frontend/cascade/methods.html frontend/cascade/methods.js; do
        cp -a "$LOCAL_SOURCE/$file" "$TEMP_DIR/source/$file"
    done
    if [[ -s "$LOCAL_SOURCE/assets/OpenFlux-linux-amd64" ]]; then
        cp -a "$LOCAL_SOURCE/assets/OpenFlux-linux-amd64" "$TEMP_DIR/source/assets/OpenFlux-linux-amd64"
    else
        cp -a "$LOCAL_SOURCE/OpenFlux-linux-amd64" "$TEMP_DIR/source/assets/OpenFlux-linux-amd64"
    fi
    for file in amneziawg-go-linux-amd64 awg-linux-amd64 awg-quick-linux-amd64; do
        cp -a "$LOCAL_SOURCE/assets/$file" "$TEMP_DIR/source/assets/$file"
    done
    for file in caddy-forwardproxy-naive-v2.11.7-naive2.tar.xz mita-v3.39.0-linux-amd64.tar.gz mieru-v3.39.0-source.tar.gz; do
        cp -a "$LOCAL_SOURCE/assets/$file" "$TEMP_DIR/source/assets/$file"
    done
    for file in preset-cars.webp preset-car-graphite.webp preset-car-silver.webp preset-car-white.webp preset-car-blue.webp preset-car-red.webp preset-car-black.webp preset-coffee.webp awg-routing-guide.mp4; do
        cp -a "$LOCAL_SOURCE/assets/$file" "$TEMP_DIR/source/assets/$file"
    done
    install -d -m 0700 "$TEMP_DIR/source/wpp-panel"
    cp -a "$LOCAL_SOURCE/wpp-panel/flags.tar.gz" "$TEMP_DIR/source/wpp-panel/flags.tar.gz"
else
fetch_github_release "$TEMP_DIR/source" "$RELEASE_REF"
fi
[[ -f "$TEMP_DIR/source/install-panel.sh" ]] || die "Update package is incomplete."
chmod 0700 "$TEMP_DIR/source/install-panel.sh"
wpp_progress 40 "Файлы обновления подготовлены"

# Retain newer records privately instead of forbidding an older release.
stage_update_controller
cp -- "$TEMP_DIR/controller/wpp_update_data.py" "$TEMP_DIR/update-data.py"
install -d -m 0700 "$TEMP_DIR/status-helper"
cp -- "$TEMP_DIR/controller/wpp_update.py" "$TEMP_DIR/controller/wpp_metrics.py" "$TEMP_DIR/status-helper/"
DATA_CURRENT_VERSION="$(cat /etc/web-proxy-panel/version 2>/dev/null || printf '0.0.0')"
python3 "$TEMP_DIR/update-data.py" prepare "$TEMP_DIR/source" /etc/web-proxy-panel "$DATA_CURRENT_VERSION" "${RELEASE_REF#v}" | tee "$TEMP_DIR/version-data-plan"
python3 "$TEMP_DIR/update-data.py" prepare-caddy "$TEMP_DIR/source" /etc/caddy/Caddyfile
# Disable services that the selected release cannot manage. Record their
# previous state so a failed install restores both data and service activation.
python3 - "$TEMP_DIR/version-data-plan" <<'PY' > "$TEMP_DIR/suspend-patterns"
import json,sys
line=next(line for line in open(sys.argv[1],encoding='utf-8') if line.startswith('WPP_VERSION_DATA '))
plan=json.loads(line.split(' ',1)[1]);protocols=plan['protocols']
if 'vless' not in protocols and 'hysteria' not in protocols:
    print('web-panel-proxy-xray.service');print('web-panel-proxy-sync-tls.timer');print('web-panel-proxy-sync-tls.service')
if 'awg20' not in protocols and 'awg31' not in protocols:print('web-panel-proxy-awg@*.service')
if 'naive' not in protocols:print('web-panel-proxy-naive.service')
if 'mieru' not in protocols:
    print('web-panel-proxy-mieru.service');print('web-panel-proxy-mieru@*.service')
if not plan['smartdns_supported']:print('web-panel-proxy-smartdns.service')
if not plan['cascade_supported']:
    print('web-panel-proxy-cascade-monitor.timer');print('web-panel-proxy-cascade-monitor.service')
PY
while IFS= read -r pattern; do
    while read -r unit _; do
        [[ "$unit" =~ ^web-panel-proxy-[a-z0-9@_.-]+\.(service|timer)$ && "$unit" != *@.service ]] || continue
        unit_enabled=0;unit_active=0
        systemctl is-enabled --quiet "$unit" 2>/dev/null && unit_enabled=1
        systemctl is-active --quiet "$unit" 2>/dev/null && unit_active=1
        [[ "$unit" == web-panel-proxy-cascade-monitor.timer && "$CASCADE_WAS_RUNNING" == 1 ]] && unit_active=1
        printf '%s %s %s\n' "$unit_enabled" "$unit_active" "$unit" >> "$TEMP_DIR/suspended-units"
        systemctl disable --now "$unit"
    done < <(systemctl list-unit-files "$pattern" --no-legend 2>/dev/null)
done < "$TEMP_DIR/suspend-patterns"

if [[ "$MIGRATING_LEGACY" == 1 ]]; then
    DOMAIN="$(sed -n 's/^Environment=TPROXY_HOSTNAME=//p' /etc/systemd/system/caddy.service.d/tproxy.conf 2>/dev/null | head -n1 || true)"
    if ! [[ "$DOMAIN" =~ ^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$ ]] && [[ -s /etc/tproxy-server/config.json ]]; then
        DOMAIN="$(sed -n 's/.*"public_hostname"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' /etc/tproxy-server/config.json | head -n1)"
    fi
    if ! [[ "$DOMAIN" =~ ^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$ ]] && [[ -s /etc/caddy/Caddyfile ]]; then
        DOMAIN="$(sed -n 's/^[[:space:]]*\([a-z0-9][a-z0-9.-]*\)[[:space:]]*{[[:space:]]*$/\1/p' /etc/caddy/Caddyfile |
            grep -vE '^(http|https|localhost)$' | head -n1 || true)"
    fi
    [[ "$DOMAIN" =~ ^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$ && "$DOMAIN" == *.* ]] ||
        die "Could not recover the domain from the first-generation installation."

    ACME_EMAIL="$(sed -n 's/^Environment=ACME_EMAIL=//p' /etc/systemd/system/caddy.service.d/tproxy.conf 2>/dev/null | head -n1 || true)"
    if ! [[ "$ACME_EMAIL" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        while true; do
            read -r -p "ACME email for the existing domain: " ACME_EMAIL
            [[ "$ACME_EMAIL" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]] && break
            echo "Invalid email."
        done
    fi

    install -d -m 0700 /etc/web-proxy-panel
    printf '%s\n' "$LEGACY_SECRET" > "$PRIMARY_SECRET"
    chmod 0600 "$PRIMARY_SECRET"
    if [[ ! -s /etc/web-proxy-panel/mtproto-host ]]; then
        MTPROTO_HOST="$(curl -4fsS --max-time 10 https://api.ipify.org 2>/dev/null || true)"
        printf '%s\n' "${MTPROTO_HOST:-$DOMAIN}" > /etc/web-proxy-panel/mtproto-host
        chmod 0600 /etc/web-proxy-panel/mtproto-host
    fi
    if [[ ! -s /etc/web-proxy-panel/caddy-owned ]]; then
        printf '%s\n' 'WEB_PANEL_PROXY_V2_CADDY_SHARED' > /etc/web-proxy-panel/caddy-owned
        chmod 0600 /etc/web-proxy-panel/caddy-owned
    fi
    install -d -m 0755 /etc/systemd/system/caddy.service.d
    cat > /etc/systemd/system/caddy.service.d/tproxy.conf <<EOF
[Service]
Environment=TPROXY_HOSTNAME=$DOMAIN
Environment=TPROXY_SITE_ROOT=/srv/tproxy-site
Environment=ACME_EMAIL=$ACME_EMAIL
ReadWritePaths=/etc/caddy
EOF
    chmod 0644 /etc/systemd/system/caddy.service.d/tproxy.conf
    systemctl daemon-reload
fi

prepare_panel_release

wpp_progress 60 "Установка компонентов панели"
if [[ "$MIGRATING_LEGACY" == 1 ]]; then
    # New panel bootstrap: install-panel asks for a login and one password,
    # creates the private URL and leaves the old core proxy data in place.
    bash "$TEMP_DIR/source/install-panel.sh"
else
    WEB_PANEL_PROXY_UPDATE=1 bash "$TEMP_DIR/source/install-panel.sh"
fi
install_update_controller
wpp_progress 90 "Финальная проверка служб"

if [[ -f "$LEGACY_SERVICE" ]]; then
    systemctl disable --now web-proxy-panel.service 2>/dev/null || true
    rm -f "$LEGACY_SERVICE"
    systemctl daemon-reload
fi

DOMAIN="$(sed -n 's/^Environment=TPROXY_HOSTNAME=//p' /etc/systemd/system/caddy.service.d/tproxy.conf | head -n1)"
PANEL_PATH="$(sed -n 's/^Environment=WEBPROXY_PANEL_PATH=//p' "$SERVICE" | head -n1 || true)"
[[ "$PANEL_PATH" =~ ^/panel-[a-z0-9-]{3,64}$ ]] || die "The updated panel address could not be read."
systemctl is-active --quiet web-proxy-panel-firewall.service ||
    die "Persistent user firewall did not start after the update."
nft list table inet web_proxy_panel >/dev/null 2>&1 ||
    die "Persistent user firewall table is missing after the update."
TARGET_HAS_XRAY="$(python3 - "$TEMP_DIR/version-data-plan" <<'PY'
import json,sys
line=next(line for line in open(sys.argv[1],encoding='utf-8') if line.startswith('WPP_VERSION_DATA '))
protocols=json.loads(line.split(' ',1)[1])['protocols']
print(int('vless' in protocols or 'hysteria' in protocols))
PY
)"
if [[ "$TARGET_HAS_XRAY" == 1 ]]; then
[[ -x /opt/web-panel-proxy/xray/xray ]] || die "Xray binary is missing after the update."
[[ -s /etc/web-panel-proxy-xray/config.json ]] || die "Xray configuration is missing after the update."
fi
command -v caddy >/dev/null 2>&1 || die "Caddy is missing after the update."
[[ -x /opt/MTProxy/objs/bin/mtproto-proxy ]] || die "MTProxy is missing after the update."
systemctl is-active --quiet caddy.service || die "Caddy did not start after the update."
if [[ "$TARGET_HAS_XRAY" == 1 ]]; then
systemctl is-active --quiet web-panel-proxy-sync-tls.timer ||
    die "The Xray TLS synchronization timer did not start after the update."
fi
systemctl is-active --quiet web-panel-proxy-auto-update.timer ||
    die "The automatic update timer did not start after the update."
PANEL_EXEC_START="$(systemctl show -p ExecStart --value tproxy-panel.service 2>/dev/null || true)"
[[ "$PANEL_EXEC_START" == *"/usr/bin/python3 /opt/tproxy-panel/panel.py"* ]] ||
    die "The panel service is not using the Python runtime after the update."
if [[ ! -s /etc/web-proxy-panel/caddy-owned ]]; then
    printf '%s\n' 'WEB_PANEL_PROXY_V2_CADDY_SHARED' > /etc/web-proxy-panel/caddy-owned
fi
printf '%s\n' "${RELEASE_REF#v}" > /etc/web-proxy-panel/version
chmod 0600 /etc/web-proxy-panel/caddy-owned /etc/web-proxy-panel/version
python3 "$TEMP_DIR/update-data.py" finalize /etc/web-proxy-panel
UPDATE_COMMITTED=1
wpp_progress 96 "Обновление Xray и OpenFlux"
flock -u 9
if [[ -n "$REQUESTED_REF" ]]; then
    echo "The selected release's Xray/OpenFlux versions are retained. Independent automatic-update settings are unchanged."
elif [[ "$TARGET_HAS_XRAY" == 1 ]] && ! systemctl start web-panel-proxy-component-auto-update.service; then
    echo "WARNING: Latest Xray/OpenFlux check failed; the automatic timer will retry." >&2
fi
if [[ "${WPP_WEB_UPDATE:-0}" != 1 ]]; then
    # The web worker owns its own result. A successful CLI install must replace
    # a stale failed web attempt, including a reinstall of the same version.
    if ! python3 - "$TEMP_DIR/status-helper" "$RELEASE_REF" "$SELECTED_RELEASE_SHA" <<'PY'
import inspect,sys
sys.path[:0]=[sys.argv[1],"/opt/tproxy-panel"]
import wpp_update
record=getattr(wpp_update,'record_cli_success',None)
if record is not None:
    source={'tag':sys.argv[2],'commit':sys.argv[3]} if sys.argv[3] else None
    if 'release_source' in inspect.signature(record).parameters:record(release_source=source)
    else:record()
PY
    then
        echo "WARNING: Installation passed, but its result could not be recorded in the panel." >&2
    fi
fi
wpp_progress 100 "Обновление завершено"
echo
echo "Update completed. Open the panel at: https://${DOMAIN}${PANEL_PATH}/login"
NODE_API_TOKEN="$(python3 - "$DOMAIN" <<'PY'
import sys
sys.path.insert(0,"/opt/tproxy-panel")
import wpp_nodes
try:
    key=open("/var/lib/tproxy-panel/api.key",encoding="ascii").read().strip()
    print(wpp_nodes.make_connection_token(sys.argv[1],key))
except (OSError,ValueError):
    pass
PY
)"
if [[ "$NODE_API_TOKEN" == wppnode1_* ]]; then
    echo "Node API token: ${NODE_API_TOKEN}"
fi
